﻿using CandidateSoW.Models;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.Intrinsics.Arm;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CandidateSoW.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CandidateController : ControllerBase
    {
        Db dbinstance = new Db();
        // GET: api/<CandidateController>
        [HttpGet]
        public List<CandidateModel> Get()
        {
            //return new string[] { "value1", "value2" };
            return dbinstance.GetAllCandidateData();
        }

        // GET api/<CandidateController>/5
        [HttpGet("{id}")]
        public List<CandidateModel> Get(int id)
        {
            return dbinstance.GetAllCandidateData().Where(e=>e.CandidateId == id).ToList();
        }

        // POST api/<CandidateController>
        [HttpPost]
        public void Post([FromBody] CandidateModel candidate)
        {
            string msg = string.Empty;
            try
            {
                msg = dbinstance.candidateTable(candidate);
            }
            catch (Exception ex)
            {
                msg = ex.Message;
            }
        }

        // PUT api/<CandidateController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] CandidateModel candidate)
        {
            string msg= string.Empty;
            try
            {
                msg= dbinstance.updateCandidateTable(id,candidate);
            }
            catch(Exception ex)
            {
                msg=ex.Message;
            }
        }

        // DELETE api/<CandidateController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            string msg = string.Empty;
            try
            {
                msg = dbinstance.deleteCandidateData(id);
            }
            catch (Exception ex)
            {
                msg = ex.Message;
            }
        }

    }
}
