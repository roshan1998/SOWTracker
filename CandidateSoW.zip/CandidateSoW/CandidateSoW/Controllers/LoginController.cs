﻿using CandidateSoW.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Data;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CandidateSoW.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        // GET: api/<LoginController>
        [HttpGet]
        public string LoginGet(string LoginName, string LoginPassword)
        {
            string msg = string.Empty;
            Db dop = new Db();
            LoginModel ln = new LoginModel();
            DataSet ds = dop.loginget(LoginName, LoginPassword);
            if (ds.Tables[0].Rows[0] !=null)
            {
                // DataColumn col = new DataColumn();
                ln.LoginName = ds.Tables[0].Rows[0]["LoginName"].ToString();
                ln.EmailId = ds.Tables[0].Rows[0]["EmailId"].ToString();
                ln.RoleName = ds.Tables[0].Rows[0]["RoleName"].ToString();
                ln.ScreenNames = ds.Tables[0].Rows[0]["ScreenNames"].ToString();
                ln.Status = ds.Tables[0].Rows[0]["Status"].ToString();
                ln.PermissionName = ds.Tables[0].Rows[0]["PermissionName"].ToString();
                return JsonConvert.SerializeObject(ln);
            }
            else
            {
                msg = "error";
                return msg;
            }

        }
    }
}
