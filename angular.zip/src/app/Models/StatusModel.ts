export interface StatusModel{
    statusId: number,
    statusName: string,
    type: string
  }