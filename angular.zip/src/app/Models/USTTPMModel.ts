export interface USTTPMModel{
    usttpmId: number,
    usttpmName: string,
    type: string
  }