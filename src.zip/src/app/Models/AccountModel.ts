export interface AccountModel{
    accountId: number,
    accountName: string,
    type: string
  }