export interface LocationModel{
        locationId: number,
        location: string,
        regionId: number,
        type: string
}