export interface RecruiterModel{
    recruiterId: number,
    recruiterName: string,
    type: string
  }