export interface TechnologyModel{
    technologyId: number,
    technologyName: string,
    domainId: number,
    type: string
  }