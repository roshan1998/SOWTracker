import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  baseUrl: string = "https://localhost:7187/api/Login";
  constructor(private http: HttpClient) { }
  isAuthor:boolean=false;
  GetUserData(httpParams:HttpParams): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}`,{ params: httpParams });
  }
}
